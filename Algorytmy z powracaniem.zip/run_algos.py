import subprocess
import os

def compile_sorts(sources_dir, bins_dir, output=False):
    if not os.path.isdir('{}'.format(bins_dir)):    
        os.mkdir('{}'.format(bins_dir))
    for algo in os.listdir(sources_dir):
        name = algo.split('.')[0]
        command = ['g++', '-o', '{}/{}'.format(bins_dir, name), '{}/{}'.format(sources_dir, algo)]
        a = subprocess.run(command, capture_output=True)
        print('Executing: {}'.format(' '.join(command)))
        if output:
            print(a.stdout.decode('utf-8'))
            print(a.stderr.decode('utf-8'))
        

def run_code(bins_dir, tests_dir, tests, time_dir, s_t, t_t, t_s, t_n, saturation, output=False):
    if not os.path.isdir(time_dir):
        os.mkdir(time_dir)
    os.chdir(time_dir)
    if not os.path.isdir(s_t):
        os.mkdir(s_t)
    os.chdir(s_t)
    if not os.path.isdir(str(saturation)):
        os.mkdir(str(saturation))
    os.chdir('..')
    os.chdir('..')
    
    test_file_name = '{}/{}/{}/{}_{}_{}.in'.format(tests_dir, t_t, str(saturation), t_s, str(saturation), t_n)
    time_output_name = '{}/{}/{}/{}_{}.time'.format(time_dir, s_t, str(saturation), t_s, t_n)
    test = open(test_file_name, 'r')
    times = open(time_output_name, 'w')
    command = ['{}/{}'.format(bins_dir, s_t)]
    subprocess.run(command, stdin=test, stdout=times, stderr=None)
    if output:
        print(' '.join(command) + '{} 1>{}'.format(test_file_name, time_output_name))
    test.close()
    times.close()
    
