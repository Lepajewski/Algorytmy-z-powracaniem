import os
import random as rnd

def hamilton(t_dir, t_type, t_sizes, num_of_t, saturation):
    os.chdir('{}'.format(t_dir))
    
    if not os.path.isdir('{}'.format(t_type)):
        os.mkdir('{}'.format(t_type))
    os.chdir('{}'.format(t_type))
    
    for i in saturation:
        if not os.path.isdir('{}'.format(i)):
            os.mkdir('{}'.format(i))
        
    for k in saturation:
        os.chdir('{}'.format(k))
        for i in t_sizes:
            for j in range(num_of_t):
                f = open('{}_{}_{}.in'.format(i, k, j), 'w')
                f.write('{}\n'.format(i))
                
                #random cycle
                cycle = [x for x in range(i)]
                rnd.shuffle(cycle)
                for l in range(len(cycle) - 1):
                    f.write('{} {}\n'.format(cycle[l], cycle[l+1]))
                f.write('{} {}\n'.format(cycle[0], cycle[-1]))
                
                n_edges = int(k * i * (i-1) - i)
                
                for l in range(n_edges):
                    f.write('{} {}\n'.format(rnd.randint(0, i-1), rnd.randint(0, i-1)))
                
                f.write('{} {}'.format(-1, -1))
                f.close()
        os.chdir('..')
    os.chdir('..')
    os.chdir('..')

def euler(t_dir, t_type, t_sizes, num_of_t, saturation):
    os.chdir('{}'.format(t_dir))
    
    if not os.path.isdir('{}'.format(t_type)):
        os.mkdir('{}'.format(t_type))
    os.chdir('{}'.format(t_type))
    
    for i in saturation:
        if not os.path.isdir('{}'.format(i)):
            os.mkdir('{}'.format(i))
        
    for k in saturation:
        os.chdir('{}'.format(k))
        for i in t_sizes:
            for j in range(num_of_t):
                f = open('{}_{}_{}.in'.format(i, k, j), 'w')
                f.write('{}\n'.format(i))
                
                cycle_length = int(k * i * (i-1))
                cycle = [x for x in range(i)]
                rnd.shuffle(cycle)
                for x in range(cycle_length - i):
                    cycle.append(rnd.randint(0, i-1))
                for x in range(1, len(cycle)-1):
                    while cycle[x-1] == cycle[x]:
                        cycle[x] = rnd.randint(0,i-1)
                    while cycle[x] == cycle[x+1]:
                        cycle[x] = rnd.randint(0,i-1)
                
                for l in range(len(cycle) - 1):
                    f.write('{} {}\n'.format(cycle[l], cycle[l+1]))
                f.write('{} {}\n'.format(cycle[0], cycle[-1]))
                
                f.write('{} {}'.format(-1, -1))
                f.close()
        os.chdir('..')
    os.chdir('..')
    os.chdir('..')
