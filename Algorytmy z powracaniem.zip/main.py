#Projekt na Algorytmy i Struktury Danych - algorytmy z powracaniem
#Łukasz Kania, I5

import test_gen
import run_algos
import os
import subprocess
import make_plots
import numpy as np
from matplotlib import pyplot as plt

TEST_SIZES = [i for i in range(100, 601, 50)] #hamilton - 10-50/ hamiltonbez - 3-15 euler\bez- 10,500,100
TEST_TYPE = ['hamilton', 'euler']
EDGES_PERCENT = [0.3, 0.5, 0.7]
TESTS = 'tests'
NUMBER_OF_TESTS = 1
SOURCES = 'sources'
RESULTS = 'results'
BINS = 'bins'
TIMES = 'times'
NUMBER_RANGE = (0, 100)
INTERVAL_RANGE = (1, 10)
INTERVAL_LENGTH = 10
CUTOFS = {'hamilton':[0, 'hamilton'], 'euler':[550, 'euler'], 'hamiltonbez':[0, 'hamilton'], 'eulerbez':[550, 'eulerbez']}
COMPILER_OUTPUT = True

 
if not os.path.isdir('{}'.format(TESTS)):
    os.mkdir('{}'.format(TESTS))

test_gen.hamilton(TESTS, TEST_TYPE[0], TEST_SIZES, NUMBER_OF_TESTS, EDGES_PERCENT)
test_gen.euler(TESTS, TEST_TYPE[1], TEST_SIZES, NUMBER_OF_TESTS, EDGES_PERCENT)

run_algos.compile_sorts(SOURCES, BINS, COMPILER_OUTPUT)

for algo in os.listdir(BINS):
    if algo == 'hamilton' or algo == 'hamiltonbez':
        for saturation in EDGES_PERCENT:
            for test_size in TEST_SIZES:
                if algo in CUTOFS and test_size > CUTOFS[algo][0] and 'hamilton' in CUTOFS[algo][1::]:
                    break
                for test_instance in range(NUMBER_OF_TESTS):
                    run_algos.run_code(BINS, TESTS, TEST_SIZES, TIMES, algo, 'hamilton', test_size, test_instance, saturation, output=COMPILER_OUTPUT)
            
    if algo == 'euler' or algo == 'eulerbez':
        for saturation in EDGES_PERCENT:
            for test_size in TEST_SIZES:
                if algo in CUTOFS and test_size > CUTOFS[algo][0] and 'euler' in CUTOFS[algo][1::]:
                    break
                for test_instance in range(NUMBER_OF_TESTS):
                    run_algos.run_code(BINS, TESTS, TEST_SIZES, TIMES, algo, 'euler', test_size, test_instance, saturation, output=COMPILER_OUTPUT)
            if algo == 'eulerbez':
                make_plots.read_times(TIMES, algo, 'eulerbez', TEST_SIZES, RESULTS, CUTOFS, saturation)   

print('done')
