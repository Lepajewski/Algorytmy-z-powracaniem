import os
from matplotlib import pyplot as plt
import numpy as np
from sklearn.linear_model import LinearRegression

def linear_plt(algo, t_type, TEST_SIZES, times, CUTOFS, results, operation):
    TEST_SIZES = TEST_SIZES[0:len(times)]
    
    x = [i for i in range(100,600,50)]
    print(x)
    y = times
    plt.plot(x, y, '.')
    
    plt.plot(x, y, label=algo+', '+str(operation))
    plt.legend()
    os.chdir(results)
    if not os.path.isdir('{}'.format('linearplots')):
        os.mkdir('{}'.format('linearplots'))
    os.chdir('{}'.format('linearplots'))
    if not os.path.isdir('{}'.format(algo)):
        os.mkdir('{}'.format(algo))
    os.chdir('..')
    os.chdir('..')
    plt.xlabel('Liczba wierzchołków')
    plt.ylabel('Czas [s]')
    plt.savefig('{}/{}/{}_{}.pdf'.format(results, 'linearplots', algo, operation))
    
    
def make_plt(algo, t_type, TEST_SIZES, times, CUTOFS, results, operation):
    TEST_SIZES = TEST_SIZES[0:len(times)]
    x = TEST_SIZES
    y = times
    plt.plot(x, y, '.', label=algo+', '+t_type)
    plt.legend()
    
    if not os.path.isdir('{}/{}/'.format(results, algo)):
        os.mkdir('{}/{}/'.format(results, algo))
    plt.xlabel('Liczba wierchołków')
    plt.ylabel('Czas [s]')    
    plt.savefig('{}/{}/{}_{}_{}.pdf'.format(results, algo, algo, t_type, operation))
    plt.clf()

def read_times(times_dir, algo_type, test_type, TEST_SIZES, res_dir, CUTOFS, saturation):
    if not os.path.isdir('{}'.format(times_dir)):
        os.mkdir('{}'.format(times_dir))
    os.chdir('{}'.format(times_dir))
    if not os.path.isdir('{}'.format(algo_type)):
        os.mkdir('{}'.format(algo_type))
    os.chdir('{}'.format(algo_type))
    os.chdir('..')
    os.chdir('..')
    
    path = '{}/{}/{}'.format(times_dir, algo_type, saturation)
    print(path)
    if not os.path.isdir('{}'.format(res_dir)):
        os.mkdir(res_dir)
    times = []
    
    for test in os.listdir(path):
        t = open('{}/{}'.format(path, test), 'r')
        l = 0
        for line in t:
            if l < 2:
                if l == 0:
                    times.append(float(line))
            l += 1
        t.close()
    
    linear_plt(algo_type, 'euler', TEST_SIZES, sorted(times), CUTOFS, res_dir, saturation)
