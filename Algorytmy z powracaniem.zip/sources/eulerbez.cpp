#include <stdio.h>
#include <vector>
#include <deque>
#include <algorithm>
#include <time.h>

class Graph
{
private:
    int n_vertices;
    int *visited;
    int *Ecycle;
    
public:
    int **graphMatrix;
    Graph(int n);
    virtual ~Graph();
    void addEdge(int x, int y);
    void findCycle(int vertex, std::deque<int>& cycle_path, int **cpmat);
    std::deque<int> ECycle();
};

Graph::Graph(int n)
{
    n_vertices = n;
    visited = new int [n_vertices];
    Ecycle = new int [n_vertices + 1];
    
    graphMatrix = new int* [n_vertices];
    
    for (int i = 0; i < n_vertices; i++)
    {
        graphMatrix[i] = new int [n_vertices];
        for (int j = 0; j < n_vertices; j++)
            graphMatrix[i][j] = 0;
    }
}

Graph::~Graph()
{
    for (int i = 0; i < n_vertices; i++)
        delete [] graphMatrix[i];
    delete [] graphMatrix;
    delete [] visited;
    delete [] Ecycle;
}

void Graph::addEdge(int x, int y)
{
    if (x >= 0 && y >= 0 && x < n_vertices && y < n_vertices && x != y)
    {
            graphMatrix[x][y] = 1;
            graphMatrix[y][x] = 1;
    }
}

void Graph::findCycle(int vertex, std::deque<int>& cycle_path, int **cpmat)
{

    
    for (int i = 0; i < n_vertices; i++)
    {
        if (cpmat[vertex][i]){
            cpmat[vertex][i] = 0;
            cpmat[i][vertex] = 0;
            findCycle(i, cycle_path, cpmat);
        }
    }
    cycle_path.push_front(vertex);
}

std::deque<int> Graph::ECycle()
{
    std::deque<int> cycle_path;
    int **CopyMatrix;
    CopyMatrix = new int* [n_vertices];
    for (int i = 0; i < n_vertices; i++)
    {
        CopyMatrix[i] = new int [n_vertices];
        for (int j = 0; j < n_vertices; j++)
            CopyMatrix[i][j] = graphMatrix[i][j];
    }
    findCycle(0, cycle_path, CopyMatrix);
    
    for (int i = 0; i < n_vertices; i++)
        delete [] CopyMatrix[i];
    delete [] CopyMatrix;
    if (cycle_path[0] == cycle_path[cycle_path.size() - 1])
        return cycle_path; //znaleziono cykl
    return std::deque<int>(); //nie ma cyklu
}

int main()
{
    int V, from, to, max_edges;
    clock_t start, end;
    double time;
    Graph *g;
    
    scanf("%d", &V);
    g = new Graph(V);
    max_edges = V * (V - 1);

    for (int i = 0; i < max_edges; i++)
    {
        scanf("%d %d", &from, &to);
        if (from == -1 && to == -1)
            break;
        g->addEdge(from, to);
    }
    
    int n = 0;
    for (int i = 0; i < V; i++)
    {
        if (g->graphMatrix[0][i] == 1 && n < 1)
            n++;
        else if (g->graphMatrix[0][i] == 1 && n >= 1)
        {
            g->graphMatrix[0][i] = 0;
            g->graphMatrix[i][0] = 0;
            n++;
        }
    }
    
    start = clock();
    std::deque<int> euler_cycle = g->ECycle();
    end = clock();
    time = ((double) (end - start)) / CLOCKS_PER_SEC;
    
    printf("%lf", time);

    return 0;
}
