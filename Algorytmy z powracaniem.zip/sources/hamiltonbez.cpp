#include <stdio.h>
#include <vector>
#include <deque>
#include <algorithm>
#include <time.h>

class Graph
{
private:
    int n_vertices;
    int *visited;
    int *Hcycle;
    
public:
    int **graphMatrix;
    Graph(int n);
    virtual ~Graph();
    void addEdge(int x, int y);
    std::vector<std::vector<int>> adjMatToadjList();
    bool findCycle(std::deque<int>& visited, std::vector<std::vector<int>> adjList);
    std::deque<int> HCycle(std::vector<std::vector<int>> adjList);
};

Graph::Graph(int n)
{
    n_vertices = n;
    visited = new int [n_vertices];
    Hcycle = new int [n_vertices + 1];
    
    graphMatrix = new int* [n_vertices];
    
    for (int i = 0; i < n_vertices; i++)
    {
        graphMatrix[i] = new int [n_vertices];
        for (int j = 0; j < n_vertices; j++)
            graphMatrix[i][j] = 0;
    }
}

Graph::~Graph()
{
    for (int i = 0; i < n_vertices; i++)
        delete [] graphMatrix[i];
    delete [] graphMatrix;
    delete [] visited;
    delete [] Hcycle;
}

void Graph::addEdge(int x, int y)
{
    if (x >= 0 && y >= 0 && x < n_vertices && y < n_vertices && x != y)
    {
            graphMatrix[x][y] = 1;
            graphMatrix[y][x] = 1;
    }
}

std::vector<std::vector<int>> Graph::adjMatToadjList()
{
    std::vector<std::vector<int>> list(n_vertices);
    
    for (int i = 0; i < n_vertices; i++)
        for (int j = 0; j < n_vertices; j++)
            if (graphMatrix[i][j] == 1)
                list[i].push_back(j);
    
    return list;
}

int different(std::vector<int> ListOfU, std::deque<int> vertices)
{   
    for (auto i : ListOfU)
        if (std::find(vertices.begin(), vertices.end(), i) == vertices.end())
            return 1;
    return 0;
}

int allVertices(int n, std::deque<int> vertices)
{
    if (n == vertices.size())
        for (int i = 0; i < n; i++)
            if (std::find(vertices.begin(), vertices.end(), i) == vertices.end())
                return 0;
    else
        return 0;
    return 1;
}

bool Graph::findCycle(std::deque<int>& visited, std::vector<std::vector<int>> adjList)
{
    visited.push_front(0); //dodajemy początkowy wierzchołek do "stosu"
    int u = adjList[0][0]; 
    std::vector<int> listWithoutVertices;
    
    while (!visited.empty())
    {
        visited.push_front(u); //dodajemy pierwszy z jego następników

        if (visited.size() == n_vertices && graphMatrix[u][0] == 1 )
        { //znaleziono cykl
            visited.push_front(0);
            return true;
        }
        //L(u) \ S jest niepusty - dodajemy pierwszy następnik
        if (different(adjList[u], visited))
        {
            for (auto i : adjList[u])
                if (std::find(visited.begin(), visited.end(), i) == visited.end())
                    listWithoutVertices.push_back(i);
                
            u = listWithoutVertices[0];
        }
        else //L(u) \ S jest pusty - trzeba się cofnąć
        {
            int w;
            bool end = 0;
            
            while (!end && visited.size() > 0)
            {
                w = visited[0];
                visited.pop_front();
                u = visited[0];

                for (auto i : adjList[u])
                    if (std::find(visited.begin(), visited.end(), i) == visited.end())
                        listWithoutVertices.push_back(i);

                for (int i = 0; i < listWithoutVertices.size() - 1; i++)
                if (w == listWithoutVertices[i])
                    {
                        u = listWithoutVertices[i + 1];
                        end = 1;
                        break;
                    }
                listWithoutVertices.clear();
            }
        }
        listWithoutVertices.clear();
    }
    return false;
}

std::deque<int> Graph::HCycle(std::vector<std::vector<int>> adjList)
{
    std::deque<int> visited;
    
    if (findCycle(visited, adjList))
        return visited; //znaleziono cykl
    return std::deque<int>(); //nie ma cyklu
}

int main()
{
    int V, from, to, max_edges;
    Graph *g;
    clock_t start, end;
    double time;
    
    scanf("%d", &V);
    g = new Graph(V);
    max_edges = V * (V - 1);

    for (int i = 0; i < max_edges; i++)
    {
        scanf("%d %d", &from, &to);
        if (from == -1 && to == -1)
            break;
        g->addEdge(from, to);
    }

    int n = 0;
    for (int i = 0; i < V; i++)
    {
        if (g->graphMatrix[0][i] == 1 && n < 1)
            n++;
        else if (g->graphMatrix[0][i] == 1 && n >= 1)
        {
            g->graphMatrix[0][i] = 0;
            g->graphMatrix[i][0] = 0;
            n++;
        }
    }
    
    std::vector<std::vector<int>> adjList = g->adjMatToadjList();
    
    start = clock();
    std::deque<int> hamiltonian_cycle = g->HCycle(adjList);
    end = clock();
    
    time = ((double) (end - start)) / CLOCKS_PER_SEC;
    
    printf("%lf", time);
    
    return 0;
}
